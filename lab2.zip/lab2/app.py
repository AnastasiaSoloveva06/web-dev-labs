from flask import Flask, render_template, request, redirect, url_for
import re

app = Flask(__name__)
# Функция для форматирования номера телефона
def format_phone(digits):
    # Приводим к стандарту 8-XXX-XXX-XX-XX

    if len(digits) == 11:
        main_part = digits[1:]
    else:
        main_part = digits
    
    return f"8-{main_part[0:3]}-{main_part[3:6]}-{main_part[6:8]}-{main_part[8:10]}"

@app.route('/', methods=['GET', 'POST'])
def request_data():
    auth_data = None
    if request.method == 'POST' and 'username' in request.form:
        auth_data = {
            'username': request.form.get('username'),
            'password': request.form.get('password')
        }

    data = {
        'args': request.args,
        'headers': request.headers,
        'cookies': request.cookies,
        'form': request.form,
        'auth_data': auth_data
    }
    return render_template('request_data.html', data=data)

@app.route('/phone', methods=['GET', 'POST'])
def phone_check():
    phone_input = ""
    error_msg = None
    formatted_phone = None
    
    if request.method == 'POST':
        phone_input = request.form.get('phone', '')
        
        # 1. Проверка на недопустимые символы
        # Разрешены цифры, пробелы, (), -, ., +
        if not re.fullmatch(r'[0-9\s\(\)\-\.\+]+', phone_input):
            error_msg = "Недопустимый ввод. В номере телефона встречаются недопустимые символы."
        else:
            # Очищаем от всего, кроме цифр
            digits = re.sub(r'\D', '', phone_input)
            length = len(digits)
            
            # 2. Логика проверки количества цифр
            is_valid_len = False
            if (phone_input.startswith('+7') or phone_input.startswith('8')) and length == 11:
                is_valid_len = True
            elif not (phone_input.startswith('+7') or phone_input.startswith('8')) and length == 10:
                is_valid_len = True
                
            if not is_valid_len:
                error_msg = "Недопустимый ввод. Неверное количество цифр."
            else:
                formatted_phone = format_phone(digits)

    return render_template('phone_check.html', 
                           phone_input=phone_input, 
                           error_msg=error_msg, 
                           formatted_phone=formatted_phone)




if __name__ == '__main__':
    app.run(debug=True)